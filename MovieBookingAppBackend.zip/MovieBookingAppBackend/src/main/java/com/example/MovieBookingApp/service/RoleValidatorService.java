package com.example.MovieBookingApp.service;

public interface RoleValidatorService {
    void validateAdmin(String username);
}
