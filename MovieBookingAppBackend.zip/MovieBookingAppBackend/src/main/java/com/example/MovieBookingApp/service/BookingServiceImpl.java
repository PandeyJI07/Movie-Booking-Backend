package com.example.MovieBookingApp.service;
import com.example.MovieBookingApp.model.Booking;
import com.example.MovieBookingApp.model.Movie;
import com.example.MovieBookingApp.repository.BookingRepository;
import com.example.MovieBookingApp.repository.MovieRepository;

import java.util.List;
import java.util.stream.Collectors;
import com.example.MovieBookingApp.DTO.BookingResponseDTO;


// import com.example.MovieBookingApp.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// import com.example.MovieBookingApp.DTO.BookingResponseDTO;
import com.example.MovieBookingApp.exception.BadRequestException;
import com.example.MovieBookingApp.exception.ResourceNotFoundException;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private MovieRepository movieRepository;

@Override
public Booking bookTickets(String username, String movieName, int ticketsToBook) {
    Movie movie = movieRepository.findByMovieNameContainingIgnoreCase(movieName)
                    .stream().findFirst().orElse(null);

    if (movie == null) {
        throw new ResourceNotFoundException("Movie not found: " + movieName);
    }

    if (ticketsToBook <= 0) {
        throw new BadRequestException("Tickets must be greater than 0.");
    }

    if (movie.getAvailableTickets() < ticketsToBook) {
        throw new BadRequestException("Not enough tickets available. Only " + movie.getAvailableTickets() + " left.");
    }

    movie.setAvailableTickets(movie.getAvailableTickets() - ticketsToBook);
    movieRepository.save(movie);

    Booking booking = new Booking(username, movie.getMovieName(), movie.getTheatreName(), ticketsToBook);
    return bookingRepository.save(booking);}
@Override
public List<BookingResponseDTO> getBookingsByUsername(String username) {
    List<Booking> bookings = bookingRepository.findByUsername(username);

    return bookings.stream().map(b -> new BookingResponseDTO(
            b.getMovieName(),
            b.getTheatreName(),
            b.getNumberOfTickets(),
            b.getBookingTime()
    )).collect(Collectors.toList());}

@Override
public void cancelBooking(String bookingId) {
    Booking booking = bookingRepository.findById(bookingId)
            .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));

    // Add tickets back to the movie
    Movie movie = movieRepository.findByMovieNameContainingIgnoreCase(booking.getMovieName())
            .stream().findFirst()
            .orElseThrow(() -> new ResourceNotFoundException("Movie not found: " + booking.getMovieName()));

    movie.setAvailableTickets(movie.getAvailableTickets() + booking.getNumberOfTickets());
    movieRepository.save(movie);

    // Delete the booking
    bookingRepository.deleteById(bookingId);}
}
