package com.example.MovieBookingApp.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Document(collection = "bookings")
@Getter
@Setter
public class Booking {
    @Id
    private String id;

    private String username;
    private String movieName;
    private String theatreName;
    private int numberOfTickets;
    private LocalDateTime bookingTime;

    public Booking() {}

    public Booking(String username, String movieName, String theatreName, int numberOfTickets) {
        this.username = username;
        this.movieName = movieName;
        this.theatreName = theatreName;
        this.numberOfTickets = numberOfTickets;
        this.bookingTime = LocalDateTime.now();
    }

}
