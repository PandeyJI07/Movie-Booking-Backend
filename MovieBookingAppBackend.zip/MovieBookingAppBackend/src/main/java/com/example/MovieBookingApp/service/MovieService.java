package com.example.MovieBookingApp.service;
import java.util.List;

import com.example.MovieBookingApp.model.Movie;
public interface MovieService {
    Movie addMovie(Movie movie);
    List<Movie> getAllMovies();
    List<Movie> searchMoviesByName(String name);
    Movie updateAvailableTickets(String movieName, int newTicketCount);
    void deleteMovieById(String movieName, String id);
}
