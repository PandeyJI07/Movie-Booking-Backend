package com.example.MovieBookingApp.service;
import com.example.MovieBookingApp.model.User;

public interface UserService {
    User registerUser(User user);
    User loginUser(String username, String password);
    String forgotPassword(String username);
    boolean resetPassword(String username, String newPassword);

}