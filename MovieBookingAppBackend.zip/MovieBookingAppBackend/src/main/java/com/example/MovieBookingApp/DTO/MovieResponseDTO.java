package com.example.MovieBookingApp.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MovieResponseDTO {
    private String movieName;
    private String theatreName;
    private int availableTickets;

    public MovieResponseDTO() {}

    public MovieResponseDTO(String movieName, String theatreName, int availableTickets) {
        this.movieName = movieName;
        this.theatreName = theatreName;
        this.availableTickets = availableTickets;
    }
}
