package com.example.MovieBookingApp.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Getter;
import lombok.Setter;

@Document(collection = "movies")
@Getter
@Setter
public class Movie {
    @Id
    private String id;
    private String movieName;
    private String theatreName;
    private int totalTickets;
    private int availableTickets;

    public Movie() {}

    public Movie(String movieName, String theatreName, int totalTickets) {
        this.movieName = movieName;
        this.theatreName = theatreName;
        this.totalTickets = totalTickets;
        this.availableTickets = totalTickets;
    }
}