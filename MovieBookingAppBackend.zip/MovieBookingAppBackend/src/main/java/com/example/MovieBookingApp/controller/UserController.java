package com.example.MovieBookingApp.controller;
import com.example.MovieBookingApp.service.UserService;
import com.example.MovieBookingApp.DTO.UserRequestDTO;
import com.example.MovieBookingApp.DTO.UserResponseDTO;
import com.example.MovieBookingApp.model.User;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1.0/moviebooking")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
public ResponseEntity<UserResponseDTO> registerUser(@RequestBody UserRequestDTO userRequest) {
    User user = new User(userRequest.getUsername(), userRequest.getEmail(), userRequest.getPassword(),
                         userRequest.getContact(), userRequest.isAdmin());
    User saved = userService.registerUser(user);

    UserResponseDTO response = new UserResponseDTO(saved.getUsername(), saved.getEmail(), saved.getContact());
    return ResponseEntity.status(HttpStatus.CREATED).body(response);
}


    @PostMapping("/login")
    public User login(@RequestParam String username, @RequestParam String password) {
        return userService.loginUser(username, password);
    }

    @GetMapping("/{username}/forgot")
    public String forgotPassword(@PathVariable String username) {
        return userService.forgotPassword(username);
    }
    @PutMapping("/{username}/forgot")
    public ResponseEntity<String> resetPassword(@PathVariable String username, @RequestBody Map<String, String> payload) {
        String newPassword = payload.get("password");
        boolean success = userService.resetPassword(username, newPassword);
        return success 
        ? ResponseEntity.ok("Password updated successfully")
        : ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
}

}