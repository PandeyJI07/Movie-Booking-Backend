package com.example.MovieBookingApp.DTO;


import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter


public class BookingResponseDTO {
    private String movieName;
    private String theatreName;
    private int numberOfTickets;
    private LocalDateTime bookingTime;

    public BookingResponseDTO() {}

    public BookingResponseDTO(String movieName, String theatreName, int numberOfTickets, LocalDateTime bookingTime) {
        this.movieName = movieName;
        this.theatreName = theatreName;
        this.numberOfTickets = numberOfTickets;
        this.bookingTime = bookingTime;
    }
}