package com.example.MovieBookingApp.service;


import com.example.MovieBookingApp.exception.ResourceNotFoundException;
import com.example.MovieBookingApp.model.Movie;
import com.example.MovieBookingApp.repository.MovieRepository;
// import com.example.MovieBookingApp.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieServiceImpl implements MovieService {

    @Autowired
    private MovieRepository movieRepository;

    // ✅ Add Movie
    @Override
    public Movie addMovie(Movie movie) {
        movie.setAvailableTickets(movie.getTotalTickets()); // Set initial available tickets
        return movieRepository.save(movie);
    }

    // ✅ Search by movie name (partial match)
    @Override
    public List<Movie> searchMoviesByName(String movieName) {
        return movieRepository.findByMovieNameContainingIgnoreCase(movieName);
    }

    // ✅ Get all movies
    @Override
    public List<Movie> getAllMovies() {
        return movieRepository.findAll();
    }

    // ✅ Update available ticket count (Admin)
    @Override
    public Movie updateAvailableTickets(String movieName, int newTicketCount) {
        Movie movie = movieRepository.findByMovieNameContainingIgnoreCase(movieName)
                .stream().findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Movie not found: " + movieName));

        movie.setAvailableTickets(newTicketCount);
        return movieRepository.save(movie);
    }

    // ✅ Delete movie by ID and movieName (Admin)
    @Override
    public void deleteMovieById(String movieName, String id) {
        Movie movie = movieRepository.findById(id).orElse(null);

        if (movie == null || !movie.getMovieName().equalsIgnoreCase(movieName)) {
            throw new ResourceNotFoundException("Movie not found with given name and ID");
        }

        movieRepository.deleteById(id);
    }
}