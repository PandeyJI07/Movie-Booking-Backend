package com.example.MovieBookingApp.service;
import com.example.MovieBookingApp.DTO.AdminDashboardDTO;
import com.example.MovieBookingApp.repository.*;
import com.example.MovieBookingApp.model.Booking;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Override
    public AdminDashboardDTO getDashboardStats() {
        long totalMovies = movieRepository.count();
        long totalBookings = bookingRepository.count();

        long totalTickets = bookingRepository.findAll()
            .stream()
            .mapToLong(Booking::getNumberOfTickets)
            .sum();

        return new AdminDashboardDTO(totalMovies, totalBookings, totalTickets);
    }
}

