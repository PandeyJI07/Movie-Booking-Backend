package com.example.MovieBookingApp.service;

import com.example.MovieBookingApp.DTO.AdminDashboardDTO;

public interface AdminService {
    AdminDashboardDTO getDashboardStats();
}
