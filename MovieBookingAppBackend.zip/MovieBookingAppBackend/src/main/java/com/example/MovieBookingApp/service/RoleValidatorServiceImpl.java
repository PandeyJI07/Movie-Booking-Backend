package com.example.MovieBookingApp.service;
import com.example.MovieBookingApp.exception.BadRequestException;
import com.example.MovieBookingApp.model.User;
import com.example.MovieBookingApp.repository.UserRepository;
// import com.example.MovieBookingApp.service.RoleValidatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleValidatorServiceImpl implements RoleValidatorService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void validateAdmin(String username) {
        User user = userRepository.findByUsername(username);

        if (user == null) {
            throw new BadRequestException("User not found: " + username);
        }

        if (!user.isAdmin()) {
            throw new BadRequestException("Access denied: User is not an admin.");
        }
    }
}