package com.example.MovieBookingApp.service;

import java.util.List;

import com.example.MovieBookingApp.DTO.BookingResponseDTO;
import com.example.MovieBookingApp.model.Booking;

public interface BookingService {
    Booking bookTickets(String username, String movieName, int ticketsToBook);
    List<BookingResponseDTO> getBookingsByUsername(String username);
    void cancelBooking(String bookingId);
    

}