package com.example.MovieBookingApp.controller;

import com.example.MovieBookingApp.DTO.MovieRequestDTO;
import com.example.MovieBookingApp.DTO.MovieResponseDTO;
import com.example.MovieBookingApp.model.Movie;
import com.example.MovieBookingApp.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.MovieBookingApp.service.RoleValidatorService;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0/moviebooking")
public class MovieController {
    @Autowired
    private final RoleValidatorService roleValidatorService;
    @Autowired
    private final MovieService movieService;
    // @Autowired
    public MovieController(MovieService movieService, RoleValidatorService roleValidatorService) {
        this.movieService = movieService;
        this.roleValidatorService = roleValidatorService;
    }

    @PostMapping("/{movieName}/add")
    public MovieResponseDTO addMovie(@PathVariable String movieName,@RequestParam String username,@RequestBody MovieRequestDTO movieRequest) {
        roleValidatorService.validateAdmin(username);
        Movie movie = new Movie();
        movie.setMovieName(movieRequest.getMovieName());
        movie.setTheatreName(movieRequest.getTheatreName());
        movie.setTotalTickets(movieRequest.getTotalTickets());
        movie.setAvailableTickets(movieRequest.getTotalTickets());

    Movie saved = movieService.addMovie(movie);
    return new MovieResponseDTO(saved.getMovieName(), saved.getTheatreName(), saved.getAvailableTickets());
}


    @GetMapping("/all")
    public List<Movie> getAllMovies() {
        return movieService.getAllMovies();
    }

    @GetMapping("/movies/search/{moviename}")
    public List<Movie> searchMovies(@PathVariable String moviename) {
        return movieService.searchMoviesByName(moviename);
    }
    @PutMapping("/{movieName}/update/{tickets}")
    public Movie updateTickets(@PathVariable String movieName,@RequestParam String username,@PathVariable int tickets) {
        roleValidatorService.validateAdmin(username);
    return movieService.updateAvailableTickets(movieName, tickets);}

    @DeleteMapping("/{movieName}/delete/{id}")
    public ResponseEntity<?> deleteMovie(@PathVariable String movieName,@RequestParam String username, @PathVariable String id) {
        roleValidatorService.validateAdmin(username);
    movieService.deleteMovieById(movieName, id);
    return ResponseEntity.ok("Movie deleted successfully.");
}


}