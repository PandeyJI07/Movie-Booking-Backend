package com.example.MovieBookingApp.service;

import com.example.MovieBookingApp.model.User;
import com.example.MovieBookingApp.repository.UserRepository;
// import com.example.MovieBookingApp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public User registerUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User loginUser(String username, String password) {
        return userRepository.findByUsernameAndPassword(username, password);
    }

    @Override
    public String forgotPassword(String username) {
        User user = userRepository.findByUsername(username);
        return user != null ? user.getPassword() : "User not found";
    }
    @Override
    public boolean resetPassword(String username, String newPassword) {
        User user = userRepository.findByUsername(username);
        if (user != null) {
            user.setPassword(newPassword);
            userRepository.save(user);
            return true;
    }
    return false;
}

}
