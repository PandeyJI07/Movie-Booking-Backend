package com.example.MovieBookingApp.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Getter;
import lombok.Setter;

@Document(collection = "users")
@Getter
@Setter
public class User {

    @Id
    private String id;
    // private boolean isAdmin;


    private String username;
    private String email;
    private String password;
    private String contact;
    private boolean isAdmin;

    // Constructors
    public User() {}

    public User(String username, String email, String password, String contact, boolean isAdmin) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.contact = contact;
        this.isAdmin = isAdmin;
    }
}
