package com.example.MovieBookingApp.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserResponseDTO {
    private String username;
    private String email;
    private String contact;

    public UserResponseDTO() {}

    public UserResponseDTO(String username, String email, String contact) {
        this.username = username;
        this.email = email;
        this.contact = contact;
    }
}