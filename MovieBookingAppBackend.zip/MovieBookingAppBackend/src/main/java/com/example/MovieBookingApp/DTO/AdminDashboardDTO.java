package com.example.MovieBookingApp.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminDashboardDTO {
    private long totalMovies;
    private long totalBookings;
    private long totalTicketsBooked;

    public AdminDashboardDTO(long totalMovies, long totalBookings, long totalTicketsBooked) {
        this.totalMovies = totalMovies;
        this.totalBookings = totalBookings;
        this.totalTicketsBooked = totalTicketsBooked;
    }
}
