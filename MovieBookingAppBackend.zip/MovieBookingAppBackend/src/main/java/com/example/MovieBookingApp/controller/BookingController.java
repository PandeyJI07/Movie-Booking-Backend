package com.example.MovieBookingApp.controller;

import com.example.MovieBookingApp.service.BookingService;
import com.example.MovieBookingApp.DTO.BookingResponseDTO;
import com.example.MovieBookingApp.model.Booking;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
// import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1.0/moviebooking")
public class BookingController {

    @Autowired
    private BookingService bookingService;

   @PostMapping("/book/{movieName}")
public BookingResponseDTO bookTicket(@PathVariable String movieName,
                                     @RequestParam String username,
                                     @RequestParam int tickets) {
    Booking booking = bookingService.bookTickets(username, movieName, tickets);
    return new BookingResponseDTO(
        booking.getMovieName(),
        booking.getTheatreName(),
        booking.getNumberOfTickets(),
        booking.getBookingTime()
    );
}
@GetMapping("/history/{username}")
public List<BookingResponseDTO> getBookingHistory(@PathVariable String username) {
    return bookingService.getBookingsByUsername(username);
}
@DeleteMapping("/cancel/{bookingId}")
public ResponseEntity<String> cancelBooking(@PathVariable String bookingId) {
    bookingService.cancelBooking(bookingId);
    return ResponseEntity.ok("Booking cancelled successfully.");
}


}