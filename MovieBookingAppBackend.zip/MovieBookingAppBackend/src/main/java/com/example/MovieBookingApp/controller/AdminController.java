package com.example.MovieBookingApp.controller;
import com.example.MovieBookingApp.DTO.AdminDashboardDTO;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.MovieBookingApp.service.*;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/v1.0/moviebooking/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/dashboard")
    public AdminDashboardDTO getDashboard() {
        return adminService.getDashboardStats();
    }
}
