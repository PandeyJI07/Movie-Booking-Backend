package com.example.MovieBookingApp.DTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MovieRequestDTO {
    private String movieName;
    private String theatreName;
    private int totalTickets;

}